<?php
namespace App\Transformers;

use League\Fractal;
use App\User;
use App\UserProfile;
use App\Transformers\AttachmentTransformer;
use App\Services\AttachmentService;
use App\Attachment;

class UserAuthTransformer extends Fractal\TransformerAbstract
{
    /**
     * List of resources possible to include
     * @var array
     */
    protected $availableIncludes = [
        'user_profile', 'attachmentable', 'UserEducations'
    ];

    /**
     * @param User $user
     * @return array
     */
    public function transform(User $user)
    {
        $output = array_only($user->toArray(), ['id', 'username', 'email', 'is_active', 'is_email_confirmed', 'role_id', 'subscription_id', 'register_ip_id', 'last_login_ip_id', 'available_wallet_amount', 'user_avatar_source_id','is_trial','is_paypal_suspend','is_paypal_cancel','subscription_end']);
        return $output;
    }

    /**
     * @param User $user
     * @return Fractal\Resource\Item
     */
    public function includeUserProfile(User $user)
    {
        if ($user->user_profile) {
            return $this->item($user->user_profile, new UserProfileTransformer());
        } else {
            return null;
        }

    }

    /**
 * @param User $user
 * @return mixed
 */
    public function includeAttachmentable(User $user)
    {
        if ($user->attachments->count() > 0) {
            $user_attachments = $user->attachments->toArray();
            if (count($user_attachments) == 1) {
                if (strpos($user_attachments[0]['dir'], 'app/User/') !== false) {
                    if ($user->role_id == config('constants.ConstUserTypes.Doctor')) {
                        $user->attachments[] = Attachment::where('id', '=', config('constants.ConstAttachment.Badge'))->first();
                    }
                } else if (strpos($user_attachments[0]['dir'], 'app/Badge/') !== false) {
                    $user->attachments[] = Attachment::where('id', '=', config('constants.ConstAttachment.UserAvatar'))->first();
                }
            }
            return $this->collection($user->attachments, new AttachmentTransformer());
        } else {
            $attachments = Attachment::where('attachmentable_id', 0)->get();
            $finduser_attachments = $attachments->toArray();
            foreach ($finduser_attachments as $finduser_attachment) {
                if (strpos($finduser_attachment['dir'], 'app/User/') !== false) {
                    $user->attachments[] = Attachment::where('id', '=', config('constants.ConstAttachment.UserAvatar'))->first();
                } else if (strpos($finduser_attachment['dir'], 'app/Badge/') !== false) {
                    if ($user->role_id == config('constants.ConstUserTypes.Doctor')) {
                        $user->attachments[] = Attachment::where('id', '=', config('constants.ConstAttachment.Badge'))->first();
                    }
                } 
            }
            return $this->collection($user->attachments, new AttachmentTransformer());
        }
    }
    /**
     * @param User $user
     * @return Fractal\Resource\Item|null
     */
    public function includeUserEducations(User $user)
    {
        if ($user->UserEducations) {
            return $this->item($user->UserEducations, new \Plugins\UserEducations\Transformers\UserEducationTransformer);
        } else {
            return null;
        }

    }
}
