<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It is a breeze. Simply tell Lumen the URIs it should respond to
  | and give it the Closure to call when that URI is requested.
  |
 */
$api = $this->app->make('Dingo\Api\Routing\Router');
$api->version(['v1'], function ($api) {

    //doctor reviews user side    
    $api->post('/patient_reviews/add', 'Plugins\DoctorReviews\Controllers\DoctorReviewsController@add');
    $api->get('/patient_reviews/{userId}', 'Plugins\DoctorReviews\Controllers\DoctorReviewsController@show');
    $api->put('/patient_reviews/{id}', 'Plugins\DoctorReviews\Controllers\DoctorReviewsController@update');
    
});